import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are Maya, a cheerful and warm AI assistant for "The Coconut Grove" — a beloved beachside restaurant & cafe in Goa, India. You're friendly, enthusiastic about the food, and make guests feel welcome.

ABOUT THE RESTAURANT:
- Location: Baga Beach, North Goa (beachfront seating available)
- Hours: 8:00 AM – 11:30 PM daily (kitchen closes 11:00 PM)
- Cuisine: Goan, Indian, Continental, Seafood specialties
- Vibe: Casual beachside dining, live music Fri & Sat nights (7pm–10pm)
- Parking: Available (free for diners)

MENU HIGHLIGHTS:
Breakfast (8am–12pm):
- Full Goan Breakfast (poie, chorizo, egg) – ₹320
- Açaí Bowl – ₹380
- Masala Omelette – ₹220
- Continental Breakfast – ₹350

Starters:
- Prawn Rawa Fry – ₹480
- Chicken Cafreal – ₹420
- Veg Spring Rolls – ₹280
- Fish Tikka – ₹520

Mains:
- Goan Fish Curry & Rice – ₹480
- Prawn Balchão – ₹560
- Chicken Xacuti – ₹440
- Mushroom Xec Xec (veg) – ₹360
- Pasta Arrabiata – ₹380

Desserts:
- Bebinca (traditional Goan) – ₹220
- Chocolate Lava Cake – ₹280
- Fresh Coconut Ice Cream – ₹180

Drinks:
- Fresh Coconut Water – ₹80
- King's Beer – ₹180
- Feni Cocktails – ₹280–380
- Fresh Juices – ₹120–160

RESERVATIONS:
- Tables for 1–8 people (larger groups need advance notice)
- Peak season (Nov–March): Book 2+ days in advance
- To reserve: collect name, phone, date, time, number of guests, and any dietary preferences
- Beach sunset slots (5pm–7pm) are most popular — book early!

FAQs:
- Yes, we have vegan & vegetarian options
- Yes, we allow outside cakes for birthdays (₹200 cake-cutting charge)
- No, we don't do home delivery currently (only dine-in)
- Live music: Friday & Saturday 7pm–10pm
- Dress code: Smart casual (no beachwear inside)

COMPLAINTS: Apologize warmly, take it seriously. If food quality/service issue, offer a complimentary dessert or discount on next visit. Escalate to manager for serious complaints. Ask for their contact.

TONE: Cheerful, warm, like a friendly local who loves food. Use food emojis occasionally 🦐🥥🌴. Keep replies short and friendly — 2-3 sentences unless listing menu items.`;

const QUICK_REPLIES = [
  "🍽️ See the menu",
  "📅 Book a table",
  "🎵 Live music nights?",
  "🦐 Today's specials",
  "🌅 Sunset dining",
  "🌱 Vegan options",
];

const GREETING = `Hey there! 🌴 Welcome to **The Coconut Grove** — Baga Beach's favourite spot for fresh seafood, Goan classics, and good vibes!

I'm Maya, and I'm here to help you with reservations, our menu, or anything else. What can I do for you today? 😊`;

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: "5px", alignItems: "center", padding: "12px 16px" }}>
      {[0,1,2].map(i => (
        <div key={i} style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#e86a2a", animation: `bounce 1.2s ease-in-out ${i*0.2}s infinite` }} />
      ))}
    </div>
  );
}

function Message({ msg }) {
  const isBot = msg.role === "bot";
  const text = msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  return (
    <div style={{ display: "flex", justifyContent: isBot ? "flex-start" : "flex-end", marginBottom: "14px", animation: "fadeUp 0.3s ease" }}>
      {isBot && (
        <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "linear-gradient(135deg,#e86a2a,#c04010)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "15px", flexShrink: 0, marginRight: "10px", marginTop: "2px", boxShadow: "0 2px 8px #e86a2a55" }}>
          🥥
        </div>
      )}
      <div style={{ maxWidth: "76%", background: isBot ? "#1c1208" : "linear-gradient(135deg,#e86a2a,#c04010)", color: isBot ? "#f0e0d0" : "#fff", borderRadius: isBot ? "4px 16px 16px 16px" : "16px 4px 16px 16px", padding: "11px 15px", fontSize: "13.5px", lineHeight: 1.65, boxShadow: isBot ? "0 2px 10px rgba(0,0,0,0.4)" : "0 2px 12px rgba(232,106,42,0.35)" }}
        dangerouslySetInnerHTML={{ __html: text }} />
    </div>
  );
}

export default function RestaurantChatbot() {
  const [messages, setMessages] = useState([{ role: "bot", content: GREETING }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [reservationMade, setReservationMade] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading) return;
    setInput("");
    if (/book|reserve|reservation|table/i.test(userText)) setReservationMade(true);

    const newMessages = [...messages, { role: "user", content: userText }];
    setMessages(newMessages);
    setLoading(true);

    try {
      const history = newMessages.map(m => ({ role: m.role === "bot" ? "assistant" : "user", content: m.content }));
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: history,
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Oops! Something went wrong. Please try again 🙏";
      setMessages(m => [...m, { role: "bot", content: reply }]);
    } catch {
      setMessages(m => [...m, { role: "bot", content: "Sorry, having a little tech hiccup! Please try again in a moment. 🙏" }]);
    }
    setLoading(false);
  };

  const handleKey = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } };

  return (
    <div style={{ minHeight: "100vh", background: "#0e0804", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px", fontFamily: "system-ui" }}>
      <link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      <style>{`
        @keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-6px)}}
        @keyframes sway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}
        *{box-sizing:border-box}
        ::-webkit-scrollbar{width:4px}
        ::-webkit-scrollbar-thumb{background:#2a1808;border-radius:2px}
        textarea:focus{outline:none}
      `}</style>

      <div style={{ width: "100%", maxWidth: "480px", display: "flex", flexDirection: "column", height: "min(700px, 95vh)", background: "#120a04", border: "1px solid #2a1808", borderRadius: "20px", overflow: "hidden", boxShadow: "0 24px 80px rgba(0,0,0,0.8), 0 0 0 1px #e86a2a22" }}>

        {/* Header */}
        <div style={{ background: "linear-gradient(160deg,#1e0e04 0%,#120a04 100%)", borderBottom: "1px solid #2a1808", padding: "16px 18px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div style={{ width: "46px", height: "46px", borderRadius: "14px", background: "linear-gradient(135deg,#e86a2a,#a03010)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "22px", boxShadow: "0 4px 20px #e86a2a55", animation: "sway 3s ease-in-out infinite" }}>
              🥥
            </div>
            <div style={{ flex: 1 }}>
              <h2 style={{ color: "#f5c090", fontFamily: "Fraunces", fontSize: "19px", margin: 0, fontWeight: 700, letterSpacing: "0.01em" }}>The Coconut Grove</h2>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px" }}>
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#00cc66", boxShadow: "0 0 6px #00cc66" }} />
                <span style={{ color: "#6a3a18", fontSize: "11px", fontFamily: "JetBrains Mono" }}>Maya · Built by Harshada Solutions · Powered by Claude</span>
              </div>
            </div>
            {reservationMade && (
              <div style={{ background: "#0d1a0d", border: "1px solid #1a3a1a", borderRadius: "8px", padding: "4px 10px" }}>
                <span style={{ color: "#55aa55", fontSize: "9px", fontFamily: "JetBrains Mono" }}>Table booked ✓</span>
              </div>
            )}
          </div>

          {/* Info strip */}
          <div style={{ display: "flex", gap: "8px", marginTop: "14px" }}>
            {[["🕗", "8am–11:30pm"], ["🎵", "Live Fri & Sat"], ["🌊", "Beachfront"]].map(([icon, label]) => (
              <div key={label} style={{ flex: 1, background: "#1a0e06", border: "1px solid #2a1808", borderRadius: "8px", padding: "7px 8px", display: "flex", alignItems: "center", gap: "5px", justifyContent: "center" }}>
                <span style={{ fontSize: "11px" }}>{icon}</span>
                <span style={{ color: "#6a3a18", fontSize: "9px", fontFamily: "JetBrains Mono" }}>{label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "18px 15px 8px" }}>
          {messages.map((msg, i) => <Message key={i} msg={msg} />)}
          {loading && (
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "linear-gradient(135deg,#e86a2a,#c04010)", display: "flex", alignItems: "center", justifyContent: "center" }}>🥥</div>
              <div style={{ background: "#1c1208", borderRadius: "4px 16px 16px 16px" }}><TypingDots /></div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick replies */}
        {messages.length <= 2 && (
          <div style={{ padding: "0 14px 10px", display: "flex", gap: "6px", flexWrap: "wrap" }}>
            {QUICK_REPLIES.map(q => (
              <button key={q} onClick={() => sendMessage(q)} disabled={loading}
                style={{ background: "#1c1208", border: "1px solid #2a1808", color: "#e86a2a", borderRadius: "20px", padding: "6px 12px", fontSize: "11px", cursor: "pointer", fontFamily: "JetBrains Mono", transition: "all 0.2s", whiteSpace: "nowrap" }}
                onMouseEnter={e => e.target.style.borderColor = "#e86a2a"}
                onMouseLeave={e => e.target.style.borderColor = "#2a1808"}>
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div style={{ padding: "10px 14px 14px", borderTop: "1px solid #1c1208", background: "#0e0804" }}>
          <div style={{ display: "flex", gap: "8px", alignItems: "flex-end", background: "#1c1208", border: "1px solid #2a1808", borderRadius: "14px", padding: "8px 8px 8px 14px" }}>
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
              placeholder="Ask about the menu, book a table, or anything else..."
              rows={1} style={{ flex: 1, background: "none", border: "none", color: "#f0e0d0", fontSize: "13px", resize: "none", fontFamily: "system-ui", lineHeight: 1.5, maxHeight: "80px", outline: "none" }} />
            <button onClick={() => sendMessage()} disabled={loading || !input.trim()}
              style={{ width: "36px", height: "36px", borderRadius: "10px", background: input.trim() && !loading ? "linear-gradient(135deg,#e86a2a,#c04010)" : "#1c1208", border: `1px solid ${input.trim() && !loading ? "#e86a2a" : "#2a1808"}`, color: input.trim() && !loading ? "#fff" : "#333", cursor: input.trim() && !loading ? "pointer" : "not-allowed", fontSize: "15px", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.2s" }}>
              ↑
            </button>
          </div>
          <p style={{ color: "#2a1808", fontSize: "10px", fontFamily: "JetBrains Mono", textAlign: "center", margin: "7px 0 0 0" }}>
            Built by Harshada Solutions · Powered by Claude · The Coconut Grove
          </p>
        </div>

      </div>
    </div>
  );
}
