import { useState, useRef, useEffect } from "react";

const SYSTEM_PROMPT = `You are Priya, a warm and professional AI assistant for "Goa Luxury Realty" — a premium real estate agency in Goa, India. You speak in a friendly, helpful tone. You know everything about the agency's listings and services.

PROPERTIES AVAILABLE:
- Beachfront Villas: ₹2Cr–₹15Cr (North Goa: Anjuna, Calangute, Vagator | South Goa: Palolem, Agonda)
- Apartments: ₹45L–₹2.5Cr (Panaji, Mapusa, Margao, Porvorim)
- Commercial Spaces: ₹80L–₹8Cr (Panaji, Vasco, Margao)
- Land Plots: ₹20L–₹5Cr (various locations)
- Luxury Penthouses: ₹3Cr–₹12Cr (Dona Paula, Candolim)

SERVICES:
- Property buying & selling guidance
- Site visit scheduling (Mon–Sat, 9am–6pm)
- NRI/OCI buyer assistance
- Rental & property management
- Home loan guidance (SBI, HDFC, ICICI partner banks)
- Legal documentation support

KEY FACTS:
- Stamp duty: 3.5% (women buyers), 5% (men buyers)
- Foreign nationals & NRIs welcome with special guidance
- Response time: within 2 hours on business days
- Free property valuation available

LEAD CAPTURE: When someone wants to book a site visit or enquire seriously, collect their: full name, phone number, preferred date/time, and property type interest. Confirm you'll have an agent contact them within 2 hours.

COMPLAINTS: Apologize sincerely, empathize, and promise to escalate to a senior advisor within 1 hour. Ask for their contact details.

TONE: Warm, trustworthy, knowledgeable. Occasionally use "🌴" or "✨" to keep it friendly. Never make up specific property addresses. Keep responses concise — 2-4 sentences max unless listing options.`;

const QUICK_REPLIES = [
  "🏖️ Show beachfront villas",
  "🏢 Commercial spaces",
  "📅 Book a site visit",
  "💰 What's my budget?",
  "🌍 I'm an NRI buyer",
  "📞 Talk to an agent",
];

const GREETING = `Namaste! 🌴 I'm Priya, your personal property advisor at **Goa Luxury Realty**.

Whether you're looking for a beachfront villa, a smart investment, or your forever home in Goa — I'm here to help. What brings you here today?`;

function TypingDots() {
  return (
    <div style={{ display: "flex", gap: "4px", alignItems: "center", padding: "14px 16px" }}>
      {[0,1,2].map(i => (
        <div key={i} style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#c9a84c", opacity: 0.7, animation: `bounce 1.2s ease-in-out ${i * 0.2}s infinite` }} />
      ))}
    </div>
  );
}

function Message({ msg }) {
  const isBot = msg.role === "bot";
  const text = msg.content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  return (
    <div style={{ display: "flex", justifyContent: isBot ? "flex-start" : "flex-end", marginBottom: "14px", animation: "fadeUp 0.3s ease" }}>
      {isBot && (
        <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "linear-gradient(135deg,#c9a84c,#8a6a20)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", flexShrink: 0, marginRight: "10px", marginTop: "2px", boxShadow: "0 2px 8px #c9a84c44" }}>P</div>
      )}
      <div style={{ maxWidth: "75%", background: isBot ? "#1a1510" : "linear-gradient(135deg,#c9a84c,#a07830)", color: isBot ? "#e8dcc8" : "#000", borderRadius: isBot ? "4px 16px 16px 16px" : "16px 4px 16px 16px", padding: "12px 16px", fontSize: "13.5px", lineHeight: 1.65, boxShadow: isBot ? "0 2px 12px rgba(0,0,0,0.4)" : "0 2px 12px rgba(201,168,76,0.3)" }}
        dangerouslySetInnerHTML={{ __html: text }} />
    </div>
  );
}

export default function RealEstateChatbot() {
  const [messages, setMessages] = useState([{ role: "bot", content: GREETING }]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [leadCaptured, setLeadCaptured] = useState(false);
  const bottomRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const sendMessage = async (text) => {
    const userText = text || input.trim();
    if (!userText || loading) return;
    setInput("");

    const userMsg = { role: "user", content: userText };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setLoading(true);

    // Check for lead signals
    if (/site visit|book|appointment|call me|contact/i.test(userText)) setLeadCaptured(true);

    try {
      const history = newMessages.filter(m => m.role !== "bot" || m !== newMessages[0]).map(m => ({
        role: m.role === "bot" ? "assistant" : "user",
        content: m.content,
      }));

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: SYSTEM_PROMPT,
          messages: history,
        }),
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "I'm sorry, I couldn't process that. Please try again.";
      setMessages(m => [...m, { role: "bot", content: reply }]);
    } catch {
      setMessages(m => [...m, { role: "bot", content: "Sorry, I'm having trouble connecting. Please try again in a moment. 🙏" }]);
    }
    setLoading(false);
  };

  const handleKey = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } };

  return (
    <div style={{ minHeight: "100vh", background: "#0a0806", display: "flex", alignItems: "center", justifyContent: "center", padding: "20px", fontFamily: "system-ui" }}>
      <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
      <style>{`
        @keyframes fadeUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes bounce { 0%,80%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} }
        @keyframes shimmer { 0%{background-position:200% 0} 100%{background-position:-200% 0} }
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-thumb { background: #2a2010; border-radius: 2px; }
        textarea:focus { outline: none; }
      `}</style>

      <div style={{ width: "100%", maxWidth: "480px", display: "flex", flexDirection: "column", height: "min(700px, 95vh)", background: "#0f0d09", border: "1px solid #2a2010", borderRadius: "20px", overflow: "hidden", boxShadow: "0 24px 80px rgba(0,0,0,0.8), 0 0 0 1px #c9a84c22" }}>

        {/* Header */}
        <div style={{ background: "linear-gradient(135deg, #1a1308 0%, #0f0d09 100%)", borderBottom: "1px solid #2a2010", padding: "18px 20px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
            <div style={{ width: "44px", height: "44px", borderRadius: "12px", background: "linear-gradient(135deg,#c9a84c,#8a6a20)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "20px", boxShadow: "0 4px 16px #c9a84c44" }}>🏡</div>
            <div style={{ flex: 1 }}>
              <h2 style={{ color: "#f0d080", fontFamily: "Cormorant Garamond", fontSize: "18px", margin: 0, fontWeight: 600, letterSpacing: "0.02em" }}>Goa Luxury Realty</h2>
              <div style={{ display: "flex", alignItems: "center", gap: "6px", marginTop: "2px" }}>
                <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#00cc66", boxShadow: "0 0 6px #00cc66" }} />
                <span style={{ color: "#6a5a30", fontSize: "11px", fontFamily: "JetBrains Mono" }}>Priya · Built by Harshada Solutions · Powered by Claude</span>
              </div>
            </div>
            {leadCaptured && (
              <div style={{ background: "#1a2a1a", border: "1px solid #2a4a2a", borderRadius: "8px", padding: "4px 10px" }}>
                <span style={{ color: "#55aa55", fontSize: "9px", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.1em" }}>Lead captured ✓</span>
              </div>
            )}
          </div>
          {/* Stats bar */}
          <div style={{ display: "flex", gap: "16px", marginTop: "14px" }}>
            {[["200+", "Properties"], ["15+", "Years in Goa"], ["2hr", "Response"]].map(([v, l]) => (
              <div key={l} style={{ flex: 1, background: "#1a1308", borderRadius: "8px", padding: "8px 10px", textAlign: "center", border: "1px solid #2a2010" }}>
                <div style={{ color: "#c9a84c", fontSize: "14px", fontWeight: 700, fontFamily: "JetBrains Mono" }}>{v}</div>
                <div style={{ color: "#4a3a18", fontSize: "9px", fontFamily: "JetBrains Mono", textTransform: "uppercase", letterSpacing: "0.08em" }}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 16px 8px 16px" }}>
          {messages.map((msg, i) => <Message key={i} msg={msg} />)}
          {loading && (
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "32px", height: "32px", borderRadius: "50%", background: "linear-gradient(135deg,#c9a84c,#8a6a20)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px" }}>P</div>
              <div style={{ background: "#1a1510", borderRadius: "4px 16px 16px 16px" }}><TypingDots /></div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Quick replies */}
        {messages.length <= 2 && (
          <div style={{ padding: "0 16px 12px", display: "flex", gap: "6px", flexWrap: "wrap" }}>
            {QUICK_REPLIES.map(q => (
              <button key={q} onClick={() => sendMessage(q)} disabled={loading}
                style={{ background: "#1a1510", border: "1px solid #2a2010", color: "#c9a84c", borderRadius: "20px", padding: "6px 12px", fontSize: "11px", cursor: "pointer", fontFamily: "JetBrains Mono", transition: "all 0.2s", whiteSpace: "nowrap" }}
                onMouseEnter={e => e.target.style.borderColor = "#c9a84c"}
                onMouseLeave={e => e.target.style.borderColor = "#2a2010"}>
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div style={{ padding: "12px 16px 16px", borderTop: "1px solid #1a1510", background: "#0c0a06" }}>
          <div style={{ display: "flex", gap: "8px", alignItems: "flex-end", background: "#1a1510", border: "1px solid #2a2010", borderRadius: "14px", padding: "8px 8px 8px 14px", transition: "border-color 0.2s" }}
            onFocus={() => {}} onBlur={() => {}}>
            <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey}
              placeholder="Ask about properties, pricing, site visits..."
              rows={1} style={{ flex: 1, background: "none", border: "none", color: "#e8dcc8", fontSize: "13px", resize: "none", fontFamily: "system-ui", lineHeight: 1.5, maxHeight: "80px", outline: "none" }} />
            <button onClick={() => sendMessage()} disabled={loading || !input.trim()}
              style={{ width: "36px", height: "36px", borderRadius: "10px", background: input.trim() && !loading ? "linear-gradient(135deg,#c9a84c,#a07830)" : "#1a1510", border: `1px solid ${input.trim() && !loading ? "#c9a84c" : "#2a2010"}`, color: input.trim() && !loading ? "#000" : "#333", cursor: input.trim() && !loading ? "pointer" : "not-allowed", fontSize: "15px", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.2s" }}>
              ↑
            </button>
          </div>
          <p style={{ color: "#2a2010", fontSize: "10px", fontFamily: "JetBrains Mono", textAlign: "center", margin: "8px 0 0 0" }}>
            Built by Harshada Solutions · Powered by Claude · Goa Luxury Realty
          </p>
        </div>
      </div>
    </div>
  );
}
